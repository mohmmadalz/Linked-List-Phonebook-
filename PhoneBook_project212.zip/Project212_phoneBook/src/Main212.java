//443101660 faisal alhaqbani
//443100700 mohmmed alzobudi
//443101706 mohmmed almuhaitheef
public class Main212 {

	public static void main(String[] args) {
		
		Phonebook ph = new Phonebook();
		ph.menu();
	}

}
