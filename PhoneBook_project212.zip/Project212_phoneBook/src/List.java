//443101660 faisal alhaqbani
//443100700 mohmmed alzobudi
//443101706 mohmmed almuhaitheef
public interface List <T>{
 
	


	    public void findFirst( );  
	    public void findNext( );  
	    public T retrieve( );  
	    public void update(T e);  
	    public void insert(T e);  
	    public void remove( );  
	    public boolean full( );  
	    public boolean last();  
	    public boolean empty( ); 
	    


}

